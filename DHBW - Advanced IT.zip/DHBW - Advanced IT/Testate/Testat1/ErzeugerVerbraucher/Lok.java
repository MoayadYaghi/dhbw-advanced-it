package ErzeugerVerbraucher;

public interface Lok extends Runnable {

}
