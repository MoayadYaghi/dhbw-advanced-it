package PrivateSemaphoren;

public interface Lok extends Runnable {
}
