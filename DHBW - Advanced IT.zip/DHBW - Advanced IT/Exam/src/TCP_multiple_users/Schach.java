package TCP_multiple_users;

// DUMMY CLASS

public class Schach {

    // DUMMY FUNCTIONS

    public static Schach neuesSpiel() {
        return null;
    }

    public static String getInhalt(String msg) {
        return msg;
    }

    public static String ziehe(String zugW) {
        return zugW;
    }

    public static int getTyp(String msg) {
        return 0;
    }
}
